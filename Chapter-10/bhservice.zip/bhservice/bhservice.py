import os
import servicemanager
import shutil
import subprocess
import sys
import win32event
import win32service
import win32serviceutil

SRCDIR = 'C:\\Users\\tim\\work'       # Source of VBS script
TGTDIR = 'C:\\Windows\\TEMP'          # Where VBS is copied to and executed

class BHServerSvc(win32serviceutil.ServiceFramework):
    _svc_name_ = "BlackHatService"
    _svc_display_name_ = "Black Hat Educational Service"
    _svc_description_ = (
        "Demonstration service that executes a VBScript payload at regular intervals. "
        "For ethical use in lab/testing environments only."
    )

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.timeout = 1000 * 60  # 60 seconds
        self.vbs = os.path.join(TGTDIR, 'bhservice_task.vbs')

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        servicemanager.LogInfoMsg("BlackHatService started.")
        self.ReportServiceStatus(win32service.SERVICE_RUNNING)
        self.main()

    def main(self):
        while True:
            ret_code = win32event.WaitForSingleObject(self.hWaitStop, self.timeout)
            if ret_code == win32event.WAIT_OBJECT_0:
                servicemanager.LogInfoMsg("BlackHatService is stopping.")
                break

            try:
                src = os.path.join(SRCDIR, 'bhservice_task.vbs')
                shutil.copy(src, self.vbs)
                subprocess.call(["cscript.exe", self.vbs], shell=False)
                os.unlink(self.vbs)
                servicemanager.LogInfoMsg("Executed and removed VBS task.")
            except Exception as e:
                servicemanager.LogErrorMsg(f"[!] Failed to execute task: {e}")

if __name__ == '__main__':
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(BHServerSvc)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(BHServerSvc)
